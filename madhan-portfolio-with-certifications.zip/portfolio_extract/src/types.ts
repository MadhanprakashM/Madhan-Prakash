export interface Experience {
  id: string;
  role: string;
  company: string;
  location: string;
  period: string;
  type: 'internship' | 'live-project' | 'freelance' | 'leadership' | 'work';
  bullets: string[];
  tags: string[];
}

export interface Project {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  overview: string;
  problem: string;
  solution: string;
  tools: string[];
  results: string[];
  learnings: string;
  stats?: { value: string; label: string }[];
  link?: string;
  github?: string;
  liveDemo?: string;
  skills?: string[];
  businessImpact?: string;
  whatILearned?: string;
  myContribution?: string;
  projectOutcome?: string;
  skillsUsed?: string[];
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  date?: string;
  link?: string;
  credentialId?: string;
}

// ============================================================================
// SCALABLE CERTIFICATION SYSTEM (45+ certificates)
// ============================================================================
export type CertificationCategory =
  | 'academic'
  | 'professional'
  | 'achievement'
  | 'participation'
  | 'review';

export interface CertificationRecord {
  id: string;
  title: string;
  issuer: string;
  year: number | null;
  category: CertificationCategory;
  categoryLabel: string;
  /** 1 (lowest) – 5 (highest) importance, used to rank homepage features */
  importance: 1 | 2 | 3 | 4 | 5;
  featured: boolean;
  description: string;
  /** Small, fast-loading preview image shown on cards (e.g. .webp) */
  thumbnail: string;
  /** Full-resolution image or PDF, loaded only when the modal is opened */
  certificateUrl: string;
  credentialId?: string;
  credentialUrl?: string;
  status?: 'verified' | 'needs_verification';
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  date?: string;
  category: 'paper' | 'leadership' | 'competition' | 'activity';
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  period: string;
  grade: string;
  highlights?: string[];
}

export interface SkillItem {
  name: string;
  rating: number; // 1 to 5 rating
}

export interface SkillGroup {
  category: string;
  skills: SkillItem[];
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  feedback: string;
  avatarLetter: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  readTime: string;
  date: string;
  slug: string;
  tags: string[];
}

