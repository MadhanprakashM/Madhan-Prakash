import { CertificationRecord, CertificationCategory } from '../types';
import { certificationRecords, homepageFeaturedIds } from './certificationRecords';

// ============================================================================
// CENTRALIZED CERTIFICATION SELECTORS
// Every component (homepage strip, /certifications page, search, filters,
// modal) reads through these helpers instead of touching the raw array
// directly. This keeps certificate data defined in exactly ONE place
// (certificationRecords.ts) — see that file for how to add certificate #46.
// ============================================================================

export { certificationRecords };

export const CATEGORY_ORDER: CertificationCategory[] = [
  'academic',
  'professional',
  'achievement',
  'participation',
  'review',
];

export const CATEGORY_LABELS: Record<CertificationCategory, string> = {
  academic: 'Academic',
  professional: 'Professional / Non-Academic',
  achievement: 'Achievements',
  participation: 'Participation',
  review: 'Needs Verification',
};

/** File type is derived from the URL, never duplicated in the data record. */
export function getFileType(url: string): 'pdf' | 'image' {
  return url.toLowerCase().endsWith('.pdf') ? 'pdf' : 'image';
}

/**
 * Sort newest-year-first, then by importance (desc) as a tiebreaker.
 * Records with no year (year: null) sort to the end.
 */
export function sortByYearThenImportance(records: CertificationRecord[]): CertificationRecord[] {
  return [...records].sort((a, b) => {
    const yearA = a.year ?? -Infinity;
    const yearB = b.year ?? -Infinity;
    if (yearA !== yearB) return yearB - yearA;
    return b.importance - a.importance;
  });
}

/**
 * Homepage featured certificates, selected dynamically:
 *  1. Prefer explicit `featured: true` records
 *  2. Rank by importance (desc), then newest year (desc)
 *  3. Cap at `count` (default 6)
 * Falls back to top-importance records overall if fewer than `count`
 * certificates are marked featured, so the homepage never looks empty.
 */
export function getFeaturedCertifications(count = 6): CertificationRecord[] {
  const featured = certificationRecords.filter((c) => c.featured);
  const ranked = sortByYearThenImportance(featured).sort((a, b) => b.importance - a.importance);

  if (ranked.length >= count) {
    return ranked.slice(0, count);
  }

  // Backfill with the highest-importance non-featured records, newest first.
  const remaining = sortByYearThenImportance(
    certificationRecords.filter((c) => !c.featured)
  ).sort((a, b) => b.importance - a.importance);

  return [...ranked, ...remaining].slice(0, count);
}

/** Distinct categories actually present in the data, in canonical order. */
export function getAvailableCategories(): CertificationCategory[] {
  const present = new Set(certificationRecords.map((c) => c.category));
  return CATEGORY_ORDER.filter((cat) => present.has(cat));
}

/** Distinct years actually present in the data, newest first. */
export function getAvailableYears(): number[] {
  const years = new Set<number>();
  certificationRecords.forEach((c) => {
    if (c.year !== null) years.add(c.year);
  });
  return Array.from(years).sort((a, b) => b - a);
}

export interface CertificationFilters {
  query?: string;
  category?: CertificationCategory | 'all';
  year?: number | 'all';
}

/** Single filtering entry point used by the /certifications page. */
export function filterCertifications(
  records: CertificationRecord[],
  { query, category, year }: CertificationFilters
): CertificationRecord[] {
  let result = records;

  if (category && category !== 'all') {
    result = result.filter((c) => c.category === category);
  }

  if (year && year !== 'all') {
    result = result.filter((c) => c.year === year);
  }

  if (query && query.trim().length > 0) {
    const q = query.trim().toLowerCase();
    result = result.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.issuer.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        (c.credentialId ?? '').toLowerCase().includes(q)
    );
  }

  return sortByYearThenImportance(result);
}

export { homepageFeaturedIds };
