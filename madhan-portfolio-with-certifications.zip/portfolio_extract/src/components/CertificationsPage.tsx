import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { Search, ArrowLeft, X, LayoutGrid } from 'lucide-react';
import {
  certificationRecords,
  filterCertifications,
  getAvailableCategories,
  getAvailableYears,
  CATEGORY_LABELS,
} from '../data/certifications';
import { CertificationCategory, CertificationRecord } from '../types';
import CertificationCard from './CertificationCard';
import CertificationDetailModal from './CertificationDetailModal';

interface CertificationsPageProps {
  onBack: () => void;
}

export default function CertificationsPage({ onBack }: CertificationsPageProps) {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<CertificationCategory | 'all'>('all');
  const [year, setYear] = useState<number | 'all'>('all');
  const [activeCert, setActiveCert] = useState<CertificationRecord | null>(null);

  const categories = useMemo(() => getAvailableCategories(), []);
  const years = useMemo(() => getAvailableYears(), []);

  const results = useMemo(
    () => filterCertifications(certificationRecords, { query, category, year }),
    [query, category, year]
  );

  const hasActiveFilters = query.trim().length > 0 || category !== 'all' || year !== 'all';

  return (
    <div className="min-h-screen bg-brand-bg relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Back navigation */}
        <button
          id="certifications-page-back-btn"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-semibold text-brand-paragraph hover:text-brand-purple transition-colors mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Portfolio
        </button>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="max-w-3xl space-y-2 md:space-y-3 mb-8"
        >
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-white/60 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800/80 rounded-full text-brand-purple text-xs font-semibold uppercase tracking-[0.24em] shadow-2xs backdrop-blur-md">
            <LayoutGrid className="w-3 h-3" />
            <span>FULL ARCHIVE</span>
          </div>
          <h1 className="text-[clamp(2rem,4.5vw,3.5rem)] font-display font-bold text-brand-dark tracking-[-0.03em]">
            All Certifications
          </h1>
          <p className="text-slate-700/85 dark:text-slate-300/85 text-[15px] sm:text-[17px] font-sans font-normal leading-relaxed max-w-[680px]">
            {certificationRecords.length} certificates and credentials across academics, professional
            training, achievements, and event participation — newest first.
          </p>
        </motion.div>

        {/* Search */}
        <div className="relative mb-4 max-w-xl">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            id="certifications-search-input"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search certificates by title, issuer, or credential ID…"
            className="w-full pl-11 pr-10 py-3 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm text-brand-dark placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-purple/30 focus:border-brand-purple transition-all"
          />
          {query && (
            <button
              id="certifications-search-clear-btn"
              onClick={() => setQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-brand-purple cursor-pointer"
              aria-label="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category filter chips */}
        <div className="flex flex-wrap gap-2 mb-3">
          <button
            id="certifications-filter-category-all"
            onClick={() => setCategory('all')}
            className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all duration-200 cursor-pointer border ${
              category === 'all'
                ? 'bg-white dark:bg-slate-900 border-2 border-brand-purple text-brand-purple shadow-sm'
                : 'bg-white/45 dark:bg-slate-900/60 border-slate-200/80 dark:border-slate-800/80 text-brand-paragraph hover:border-brand-purple/45 hover:text-brand-purple'
            }`}
          >
            All Categories
          </button>
          {categories.map((cat) => (
            <button
              id={`certifications-filter-category-${cat}`}
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all duration-200 cursor-pointer border ${
                category === cat
                  ? 'bg-white dark:bg-slate-900 border-2 border-brand-purple text-brand-purple shadow-sm'
                  : 'bg-white/45 dark:bg-slate-900/60 border-slate-200/80 dark:border-slate-800/80 text-brand-paragraph hover:border-brand-purple/45 hover:text-brand-purple'
              }`}
            >
              {CATEGORY_LABELS[cat]}
            </button>
          ))}
        </div>

        {/* Year filter chips */}
        {years.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-8">
            <button
              id="certifications-filter-year-all"
              onClick={() => setYear('all')}
              className={`px-3.5 py-1.5 rounded-full text-[11px] font-bold tracking-wide transition-all duration-200 cursor-pointer border ${
                year === 'all'
                  ? 'bg-brand-purple/10 border-brand-purple text-brand-purple'
                  : 'bg-transparent border-slate-200 dark:border-slate-800 text-brand-paragraph hover:border-brand-purple/45 hover:text-brand-purple'
              }`}
            >
              All Years
            </button>
            {years.map((y) => (
              <button
                id={`certifications-filter-year-${y}`}
                key={y}
                onClick={() => setYear(y)}
                className={`px-3.5 py-1.5 rounded-full text-[11px] font-bold tracking-wide transition-all duration-200 cursor-pointer border ${
                  year === y
                    ? 'bg-brand-purple/10 border-brand-purple text-brand-purple'
                    : 'bg-transparent border-slate-200 dark:border-slate-800 text-brand-paragraph hover:border-brand-purple/45 hover:text-brand-purple'
                }`}
              >
                {y}
              </button>
            ))}
          </div>
        )}

        {/* Results count */}
        <p className="text-xs font-semibold text-brand-paragraph mb-4">
          Showing {results.length} of {certificationRecords.length} certificates
          {hasActiveFilters && (
            <button
              id="certifications-filters-reset-btn"
              onClick={() => {
                setQuery('');
                setCategory('all');
                setYear('all');
              }}
              className="ml-3 text-brand-purple hover:underline cursor-pointer"
            >
              Reset filters
            </button>
          )}
        </p>

        {/* Results grid — thumbnails only, lazy-loaded; full files load solely on modal open */}
        {results.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
            {results.map((cert) => (
              <CertificationCard key={cert.id} certification={cert} onView={setActiveCert} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 text-brand-paragraph text-sm font-medium">
            No certificates match your filters.
          </div>
        )}
      </div>

      {activeCert && (
        <CertificationDetailModal certification={activeCert} onClose={() => setActiveCert(null)} />
      )}
    </div>
  );
}
