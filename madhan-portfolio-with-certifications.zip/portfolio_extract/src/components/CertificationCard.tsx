import React, { useState } from 'react';
import { ShieldCheck, GraduationCap, Eye, ImageOff } from 'lucide-react';
import { CertificationRecord } from '../types';

interface CertificationCardProps {
  certification: CertificationRecord;
  onView: (certification: CertificationRecord) => void;
}

/**
 * Card used on BOTH the homepage featured strip and the /certifications
 * page. Only ever renders the small `thumbnail` — never the full-res
 * `certificateUrl` — and the thumbnail uses native lazy-loading so
 * off-screen cards don't trigger a network request until scrolled into
 * view.
 */
export default function CertificationCard({ certification, onView }: CertificationCardProps) {
  const [thumbFailed, setThumbFailed] = useState(false);

  return (
    <div
      id={`certification-card-${certification.id}`}
      className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/85 hover:bg-slate-50/20 dark:hover:bg-slate-950/20 hover:border-brand-purple/20 hover:shadow-lg hover:-translate-y-1.5 transition-all duration-250 ease-out flex flex-col justify-between group"
    >
      <div className="space-y-3">
        {/* Thumbnail (lazy-loaded) */}
        <button
          id={`certification-card-thumb-btn-${certification.id}`}
          onClick={() => onView(certification)}
          className="relative w-full aspect-video rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-800/60 cursor-pointer block"
          aria-label={`View certificate: ${certification.title}`}
        >
          {!thumbFailed ? (
            <img
              src={certification.thumbnail}
              alt={certification.title}
              loading="lazy"
              decoding="async"
              onError={() => setThumbFailed(true)}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 ease-out"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-slate-300 dark:text-slate-700">
              <ImageOff className="w-6 h-6" />
            </div>
          )}
          <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/30 transition-colors duration-250 flex items-center justify-center">
            <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-250 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/95 text-brand-dark text-[11px] font-bold">
              <Eye className="w-3.5 h-3.5" /> View Certificate
            </span>
          </div>
        </button>

        {/* Verified badge */}
        <div className="flex justify-between items-start">
          <div className="w-9 h-9 rounded-lg bg-brand-purple/5 dark:bg-brand-purple/10 border border-brand-purple/10 dark:border-brand-purple/20 text-brand-purple flex items-center justify-center group-hover:rotate-6 group-hover:scale-105 transition-all duration-250 ease-out">
            <GraduationCap className="w-4.5 h-4.5" />
          </div>
          {certification.status === 'verified' && (
            <span className="flex items-center space-x-1 text-[11px] text-brand-success font-bold bg-emerald-50 dark:bg-emerald-950/45 border border-emerald-100 dark:border-emerald-900/40 px-2 py-0.5 rounded-full">
              <ShieldCheck className="w-3 h-3" />
              <span>Verified</span>
            </span>
          )}
        </div>

        {/* Title & Issuer */}
        <div className="space-y-1">
          <h3 className="font-display font-bold text-brand-dark text-sm sm:text-base tracking-tight leading-snug group-hover:text-brand-purple transition-colors duration-250">
            {certification.title}
          </h3>
          <p className="text-xs text-brand-paragraph font-medium">
            Issued by <span className="text-brand-dark font-bold">{certification.issuer}</span>
          </p>
          {certification.credentialId && (
            <p className="text-xs text-brand-paragraph font-mono mt-1.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200/50 dark:border-slate-800/50 py-0.5 px-2 rounded w-fit">
              ID: <span className="text-brand-dark font-semibold">{certification.credentialId}</span>
            </p>
          )}
        </div>
      </div>

      {/* Footer and Date */}
      <div className="flex justify-between items-center border-t border-slate-100 dark:border-slate-800/60 mt-4 pt-3 text-[11px] font-semibold text-brand-paragraph">
        <span>{certification.year ?? 'Pending'}</span>
        <button
          id={`certification-card-view-btn-${certification.id}`}
          onClick={() => onView(certification)}
          className="text-brand-purple flex items-center hover:underline cursor-pointer font-bold group-hover:translate-x-0.5 transition-transform duration-250"
        >
          View Certificate
        </button>
      </div>
    </div>
  );
}
