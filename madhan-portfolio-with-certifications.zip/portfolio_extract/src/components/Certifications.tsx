import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { getFeaturedCertifications, certificationRecords } from '../data/certifications';
import { CertificationRecord } from '../types';
import CertificationCard from './CertificationCard';
import CertificationDetailModal from './CertificationDetailModal';

export default function Certifications() {
  // Dynamically selected: featured=true, ranked by importance, then newest year.
  // See src/data/certifications.ts -> getFeaturedCertifications()
  const featuredCertifications = getFeaturedCertifications(6);
  const [activeCert, setActiveCert] = useState<CertificationRecord | null>(null);

  const animateFadeUp = {
    hidden: { opacity: 0, y: 30, filter: 'blur(5px)' },
    visible: {
      opacity: 1,
      y: 0,
      filter: 'blur(0px)',
      transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as any }
    }
  };

  return (
    <section id="certifications" className="py-8 sm:py-12 md:py-14 bg-transparent relative overflow-hidden">
      {/* Subtle background matrix layout */}
      <div className="absolute inset-0 matrix-grid-pattern opacity-30 pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10"
      >

        {/* Section Header */}
        <motion.div
          className="max-w-3xl mx-auto text-center mb-5 md:mb-6 space-y-2 md:space-y-3"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={animateFadeUp}
        >
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-white/60 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800/80 rounded-full text-brand-purple text-xs font-semibold uppercase tracking-[0.24em] shadow-2xs backdrop-blur-md">
            <span>VERIFIED CREDENTIALS</span>
          </div>
          <h2 className="text-[clamp(2.5rem,5vw,4rem)] font-display font-bold text-brand-dark tracking-[-0.03em]">
            Professional Certifications
          </h2>
          <div className="w-12 h-1 bg-brand-purple mx-auto rounded-full" />
          <p className="text-slate-700/85 dark:text-slate-300/85 text-[16px] sm:text-[18px] font-sans font-normal leading-relaxed sm:leading-[1.9] max-w-[680px] mx-auto">
            Continuous professional training and digital marketing credentials completed alongside MBA coursework.
          </p>
        </motion.div>

        {/* Featured Certifications Grid (homepage shows only the top 6 — full-res thumbnails
            for the other {certificationRecords.length - featuredCertifications.length} certificates
            are never requested on this page) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {featuredCertifications.map((cert) => (
            <CertificationCard key={cert.id} certification={cert} onView={setActiveCert} />
          ))}
        </div>

        {/* Link to full certifications archive */}
        {certificationRecords.length > featuredCertifications.length && (
          <div className="mt-6 text-center">
            <a
              id="certs-view-all-link"
              href="#/certifications"
              className="inline-flex items-center space-x-2 px-8 py-4 rounded-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-brand-purple text-xs font-semibold uppercase tracking-wider hover:bg-slate-50/50 dark:hover:bg-slate-800 hover:scale-[1.02] hover:shadow-md transition-all duration-250 ease-out active:scale-98 cursor-pointer"
            >
              <span>View All Certifications ({certificationRecords.length})</span>
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        )}

      </motion.div>

      {activeCert && (
        <CertificationDetailModal certification={activeCert} onClose={() => setActiveCert(null)} />
      )}
    </section>
  );
}
