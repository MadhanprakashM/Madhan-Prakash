import React, { useEffect, useState, useCallback } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  X,
  ShieldCheck,
  Calendar,
  Building2,
  Tag,
  Hash,
  ExternalLink,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Loader2,
  AlertTriangle,
} from 'lucide-react';
import { CertificationRecord } from '../types';
import { getFileType } from '../data/certifications';

interface CertificationDetailModalProps {
  certification: CertificationRecord;
  onClose: () => void;
}

/**
 * Reusable certificate viewer modal.
 *
 * IMPORTANT (performance): the full-resolution image / PDF referenced by
 * `certification.certificateUrl` is NOT rendered anywhere until this modal
 * itself mounts (i.e. until the user clicks "View Certificate"). Only the
 * small thumbnail is ever shown on cards. Closing the modal unmounts it,
 * so the original file is released from the DOM/memory.
 */
export default function CertificationDetailModal({
  certification,
  onClose,
}: CertificationDetailModalProps) {
  const fileType = getFileType(certification.certificateUrl);

  const [zoom, setZoom] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [assetLoaded, setAssetLoaded] = useState(false);
  const [assetError, setAssetError] = useState(false);

  const handleClose = useCallback(() => {
    setZoom(1);
    setIsFullscreen(false);
    onClose();
  }, [onClose]);

  // Escape key closes the modal; lock background scroll while open.
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleClose();
    };
    document.addEventListener('keydown', onKeyDown);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = prevOverflow;
    };
  }, [handleClose]);

  return (
    <AnimatePresence>
      <motion.div
        id="certification-modal-backdrop"
        className="fixed inset-0 z-100 flex items-center justify-center p-3 sm:p-6 bg-slate-900/70 backdrop-blur-md overflow-y-auto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        onClick={(e) => {
          if ((e.target as HTMLElement).id === 'certification-modal-backdrop') {
            handleClose();
          }
        }}
      >
        <motion.div
          id="certification-modal-container"
          role="dialog"
          aria-modal="true"
          aria-labelledby="certification-modal-title"
          initial={{ opacity: 0, y: 20, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 10, scale: 0.98 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className={`w-full bg-white dark:bg-slate-950 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col overflow-hidden ${
            isFullscreen ? 'max-w-[98vw] h-[96vh]' : 'max-w-3xl max-h-[92vh]'
          }`}
        >
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-brand-border flex items-start justify-between gap-3 bg-slate-50/70 dark:bg-slate-900/60 shrink-0">
            <div className="min-w-0 space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-brand-purple bg-brand-purple/8 dark:bg-brand-purple/15 border border-brand-purple/15 px-2 py-0.5 rounded-full">
                  <Tag className="w-3 h-3" />
                  {certification.categoryLabel}
                </span>
                {certification.status === 'verified' && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-brand-success bg-emerald-50 dark:bg-emerald-950/45 border border-emerald-100 dark:border-emerald-900/40 px-2 py-0.5 rounded-full">
                    <ShieldCheck className="w-3 h-3" />
                    Verified
                  </span>
                )}
              </div>
              <h3
                id="certification-modal-title"
                className="font-display font-bold text-sm sm:text-lg text-brand-dark leading-snug truncate"
              >
                {certification.title}
              </h3>
            </div>
            <button
              id="certification-modal-close-btn"
              onClick={handleClose}
              className="p-2 bg-white dark:bg-slate-800 border border-brand-border text-brand-paragraph hover:text-brand-purple rounded-xl transition-all focus:outline-none cursor-pointer shrink-0"
              aria-label="Close certificate viewer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Viewer area */}
          <div className="flex-1 overflow-auto bg-slate-100 dark:bg-slate-900/60 relative flex items-center justify-center min-h-[260px]">
            {!assetError && !assetLoaded && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-brand-paragraph text-xs font-medium">
                <Loader2 className="w-6 h-6 animate-spin text-brand-purple" />
                <span>Loading certificate…</span>
              </div>
            )}

            {assetError && (
              <div className="flex flex-col items-center justify-center gap-2 text-brand-paragraph text-xs font-medium p-8 text-center">
                <AlertTriangle className="w-6 h-6 text-amber-500" />
                <span>Certificate file not available yet.</span>
              </div>
            )}

            {fileType === 'image' ? (
              <div
                className="w-full h-full overflow-auto flex items-center justify-center p-4"
                style={{ display: assetError ? 'none' : 'flex' }}
              >
                <img
                  src={certification.certificateUrl}
                  alt={certification.title}
                  onLoad={() => setAssetLoaded(true)}
                  onError={() => setAssetError(true)}
                  style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}
                  className="max-w-full h-auto rounded-lg shadow-md transition-transform duration-200 select-none"
                  draggable={false}
                />
              </div>
            ) : (
              // PDF: not requested/loaded until this modal mounts (i.e. until "View Certificate" is clicked).
              !assetError && (
                <iframe
                  title={certification.title}
                  src={certification.certificateUrl}
                  onLoad={() => setAssetLoaded(true)}
                  onError={() => setAssetError(true)}
                  className="w-full h-full min-h-[60vh] border-0"
                />
              )
            )}
          </div>

          {/* Footer: details + controls */}
          <div className="p-4 sm:p-5 border-t border-brand-border bg-slate-50/70 dark:bg-slate-900/60 shrink-0 space-y-3">
            <div className="flex flex-wrap gap-x-5 gap-y-1.5 text-xs text-brand-paragraph font-medium">
              <span className="flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-brand-purple" />
                Issued by <span className="text-brand-dark font-bold">{certification.issuer}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-brand-purple" />
                {certification.year ?? 'Year pending verification'}
              </span>
              {certification.credentialId && (
                <span className="flex items-center gap-1.5">
                  <Hash className="w-3.5 h-3.5 text-brand-purple" />
                  ID: <span className="text-brand-dark font-semibold font-mono">{certification.credentialId}</span>
                </span>
              )}
            </div>

            {certification.description && (
              <p className="text-xs sm:text-sm text-brand-paragraph leading-relaxed">
                {certification.description}
              </p>
            )}

            <div className="flex items-center justify-between gap-3 pt-1">
              <div className="flex items-center gap-2">
                {fileType === 'image' && !assetError && (
                  <>
                    <button
                      id="certification-modal-zoom-out"
                      onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
                      className="p-2 bg-white dark:bg-slate-800 border border-brand-border rounded-lg text-brand-paragraph hover:text-brand-purple transition-colors cursor-pointer"
                      aria-label="Zoom out"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <button
                      id="certification-modal-zoom-in"
                      onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
                      className="p-2 bg-white dark:bg-slate-800 border border-brand-border rounded-lg text-brand-paragraph hover:text-brand-purple transition-colors cursor-pointer"
                      aria-label="Zoom in"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                  </>
                )}
                <button
                  id="certification-modal-fullscreen-toggle"
                  onClick={() => setIsFullscreen((f) => !f)}
                  className="p-2 bg-white dark:bg-slate-800 border border-brand-border rounded-lg text-brand-paragraph hover:text-brand-purple transition-colors cursor-pointer"
                  aria-label={isFullscreen ? 'Exit fullscreen' : 'View fullscreen'}
                >
                  {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
              </div>

              {certification.credentialUrl && (
                <a
                  href={certification.credentialUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-brand-purple hover:underline"
                >
                  Verify Online <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
