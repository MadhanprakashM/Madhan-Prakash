import React, { useState, useEffect, Suspense, lazy } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import PersonalBrand from './components/PersonalBrand';
import Academic from './components/Academic';
import Experience from './components/Experience';
import Skills from './components/Skills';
import Certifications from './components/Certifications';
import Achievements from './components/Achievements';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ErrorBoundary from './components/ErrorBoundary';
import NotFound from './components/NotFound';
import PremiumBackground from './components/PremiumBackground';

const ResumePreviewModal = lazy(() => import('./components/ResumePreviewModal'));
const CertificationsPage = lazy(() => import('./components/CertificationsPage'));

export default function App() {
  const [showResumeModal, setShowResumeModal] = useState<boolean>(false);
  const [is404, setIs404] = useState<boolean>(false);
  const [isCertificationsRoute, setIsCertificationsRoute] = useState<boolean>(
    () => typeof window !== 'undefined' && window.location.hash.startsWith('#/certifications')
  );
  const [activeSection, setActiveSection] = useState<string>('home');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('theme');
      if (saved) {
        return saved === 'dark';
      }
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  // Monitor location hash to support simulated 404 views and the
  // /certifications route (hash-based so it works on any static host
  // without server-side rewrite rules).
  useEffect(() => {
    const checkHash = () => {
      setIs404(window.location.hash === '#404');
      setIsCertificationsRoute(window.location.hash.startsWith('#/certifications'));
    };
    checkHash();
    window.addEventListener('hashchange', checkHash);
    return () => window.removeEventListener('hashchange', checkHash);
  }, []);

  // Set the correct page title and metadata
  useEffect(() => {
    document.title = 'M. Madhan Prakash | MBA Portfolio & Featured Work';
  }, []);

  // Set up Intersection Observer to track scroll positions and activate the correct sticky navigation tab
  useEffect(() => {
    const sections = [
      'home',
      'about',
      'brand',
      'academic',
      'experience',
      'skills',
      'certifications',
      'achievements',
      'testimonials',
      'contact',
    ];

    const observers = sections.map((id) => {
      const el = document.getElementById(id);
      if (!el) return null;

      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setActiveSection(id);
          }
        },
        {
          rootMargin: '-80px 0px -50% 0px',
          threshold: 0.15,
        }
      );

      observer.observe(el);
      return { observer, el };
    });

    return () => {
      observers.forEach((obs) => {
        if (obs) obs.observer.unobserve(obs.el);
      });
    };
  }, []);

  return (
    <ErrorBoundary>
      {is404 ? (
        <NotFound
          onBackToHome={() => {
            window.location.hash = '';
            setIs404(false);
          }}
        />
      ) : isCertificationsRoute ? (
        <Suspense
          fallback={
            <div className="min-h-screen flex items-center justify-center">
              <div className="w-8 h-8 rounded-full border-2 border-brand-purple border-t-transparent animate-spin" />
            </div>
          }
        >
          <CertificationsPage
            onBack={() => {
              window.location.hash = '';
              setIsCertificationsRoute(false);
            }}
          />
        </Suspense>
      ) : (
        <div className="text-brand-dark min-h-screen relative font-sans antialiased selection:bg-brand-purple/15 selection:text-brand-dark overflow-x-hidden">
          {/* Layered luxury animated cinematic background */}
          <PremiumBackground />
          
          {/* Sticky responsive Navbar */}
          <Navbar
            activeSection={activeSection}
            onOpenResume={() => setShowResumeModal(true)}
            darkMode={darkMode}
            toggleDarkMode={() => setDarkMode(!darkMode)}
          />

          {/* Page Sections */}
          <main id="portfolio-scroll-container" className="space-y-0">
            
            {/* 1. Hero / Home Section */}
            <Hero onOpenResumeModal={() => setShowResumeModal(true)} />

            {/* 2. About Me Section */}
            <About />

            {/* Personal Brand Section */}
            <PersonalBrand />

            {/* 3. Academic Profile Qualifications Section */}
            <Academic />

            {/* 4. Career Milestones timeline */}
            <Experience />

            {/* 5. Tool & Strategic Competencies Matrix */}
            <Skills />

            {/* 6. Academic & Vocational Credentials */}
            <Certifications />

            {/* 7. Research Publications & Leadership Stats */}
            <Achievements />

            {/* Testimonials Endorsements Section */}
            <Testimonials />

            {/* 8. Let's Build Something Meaningful Contact Form */}
            <Contact onOpenResume={() => setShowResumeModal(true)} />

          </main>

          {/* Elegant Recruiter Footer */}
          <Footer />

          {/* Interactive Resume Sheet Modal */}
          {showResumeModal && (
            <Suspense fallback={<div className="fixed inset-0 z-100 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs"><div className="w-8 h-8 rounded-full border-2 border-brand-purple border-t-transparent animate-spin" /></div>}>
              <ResumePreviewModal onClose={() => setShowResumeModal(false)} />
            </Suspense>
          )}
          
        </div>
      )}
    </ErrorBoundary>
  );
}
