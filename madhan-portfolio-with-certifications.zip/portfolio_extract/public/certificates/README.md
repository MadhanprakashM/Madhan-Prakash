# Certificate Assets

This folder is read by `src/data/certificationRecords.ts`. Each certification
record points to two files:

- `thumbnail`   -> public/certificates/thumbnails/<file>.webp  (small preview, shown on cards)
- `certificateUrl` -> public/certificates/originals/<file>.<jpg|png|pdf>  (full-resolution file, loaded only when the modal is opened)

## Current status

The certificate metadata (titles, issuers, years, categories, importance,
credential IDs) has been imported from your CSV/JSON exports into
`src/data/certificationRecords.ts`. The actual image/PDF FILES referenced by
that metadata have not been uploaded yet, so thumbnails will show a
placeholder icon and the modal will show "Certificate file not available
yet" until you add them here with the exact filenames already listed in
each record (see `sourceFile` / `thumbnail` / `certificateUrl` fields).

## Adding certificate #46 (or filling in a missing file)

1. Add the thumbnail:  public/certificates/thumbnails/<name>.webp
2. Add the original:   public/certificates/originals/<name>.<ext>
3. Append one object to the array in `src/data/certificationRecords.ts`
   (or fix the `thumbnail`/`certificateUrl` path on an existing object).

No component needs to change. Everything (homepage featured strip, the
`/certifications` page, search, category/year filters, and the detail
modal) reads from that single data file.
